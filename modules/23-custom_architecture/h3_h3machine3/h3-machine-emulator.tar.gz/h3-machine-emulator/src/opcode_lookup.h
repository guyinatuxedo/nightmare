#ifndef _OPCODE_LOOKUP_H
#define _OPCODE_LOOKUP_H

#include "opcodes.h"

opcode_f opcode_handlers[256];
char *opcode_names[256];

#endif // _OPCODE_LOOKUP_H
